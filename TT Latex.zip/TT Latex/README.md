# ESCOM-C2-EP2
Plantilla para creación de proyectos pequeños para la clase de Análisis y Diseño Orientado a Objetos (Iteración 2)
